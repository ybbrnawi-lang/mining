
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';

const scene=new THREE.Scene();
scene.background=new THREE.Color(0x87ceeb);

const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,0.1,1000);
camera.position.set(0,15,20);

const renderer=new THREE.WebGLRenderer();
renderer.setSize(innerWidth,innerHeight);
document.body.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0xffffff,0.8));
const sun=new THREE.DirectionalLight(0xffffff,1.2);
sun.position.set(20,50,20);
scene.add(sun);

const geo=new THREE.BoxGeometry(1,1,1);

for(let x=-30;x<=30;x++){
 for(let z=-30;z<=30;z++){
  const h=Math.floor(3+Math.sin(x*0.2)*2+Math.cos(z*0.2)*2);
  for(let y=0;y<=h;y++){
   const mat=new THREE.MeshLambertMaterial({color:y===h?0x55aa55:0x8b5a2b});
   const cube=new THREE.Mesh(geo,mat);
   cube.position.set(x,y,z);
   scene.add(cube);
  }
 }
}

function animate(){
 requestAnimationFrame(animate);
 renderer.render(scene,camera);
}
animate();
