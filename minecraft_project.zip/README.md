
# Minecraft Style Project

Structure:
- index.html
- js/game.js
- textures/

Open index.html in a browser or upload to GitHub Pages.
